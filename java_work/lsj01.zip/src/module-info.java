/**
 * 
 */
/**
 * 
 */
module lsj01 {
}